library(testthat)
library(hExplorer)

test_check("hExplorer")
# test_dir("tests/testthat")
