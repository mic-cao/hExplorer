## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning = FALSE---------------------------------------------------
library(hExplorer)
library(maps)
library(sp)

## -----------------------------------------------------------------------------
storms.2020 <- unique(hurdat$id[format(hurdat$datetime, "%Y") == "2020"])
storms.2021 <- unique(hurdat$id[format(hurdat$datetime, "%Y") == "2021"])
storms.2022 <- unique(hurdat$id[format(hurdat$datetime, "%Y") == "2022"])
storm_track(storms.2020, show.legend = T)
storm_track(storms.2021, show.legend = T)
storm_track(storms.2022, show.legend = T)

## -----------------------------------------------------------------------------
names <- c("KATRINA", "SANDY", "HARVEY", "IAN")
years <- c("2005", "2012", "2017", "2022")

for(i in 1:length(names)) 
{
  
  temp <- which(endsWith(hurdat$name, names[i]) & 
                       format(hurdat$datetime, "%Y") == years[i])
  
  temp <- temp[complete.cases(hurdat[temp, grepl("34|50|64",
                                                 colnames(hurdat))])]

  temp <- temp[sapply(hurdat$datetime[temp], 
                      made_landfall, 
                      storm_id = unique(hurdat$id[temp]))]
  idx <- temp[which.max(hurdat$max_sustained[temp])]
  storm_location(hurdat$id[idx], 
                 show.track = TRUE, 
                 time.pt = hurdat$datetime[idx])
}

## -----------------------------------------------------------------------------
id <- unique(hurdat$id)
idx <- match(id, hurdat$id)

names <- hurdat$name[idx]
max_speed <- hurdat$max_sustained[idx]
min_pressure <- hurdat$min_pressure[idx]

landfall <- sapply(id, made_landfall)
accum_cyclone_energy <- sapply(id, function(x) tryCatch({cyclone_energy(x)}, error = function(e) {return(NA)}))

output <- data.frame(id, names, max_speed, min_pressure, 
                     landfall, accum_cyclone_energy)
head(output)

## ---- warning=FALSE-----------------------------------------------------------
# Plot 1: Create plots of maximum sustained wind speeds for a representative sample of storms - see if any patterns emerge
id.by.speed <- output$id[order(output$max_speed, decreasing = T)]
storm_track(id.by.speed[1:5])


# Plot 2: storms that last the longest
id <- unique(hurdat$id)
idx <- match(id, hurdat$id)

duration <- rep(NA, length(id))
for (i in seq_along(id))
{
  match_id <- which(hurdat$id==id[i])
  duration[i] <- diff(range(hurdat$datetime[match_id]))
}
id.by.duration <- output$id[order(duration, decreasing = T)]
storm_track(id.by.duration[1:5])


# Plot 3: storms that have the greatest displacement
id <- unique(hurdat$id)
idx <- match(id, hurdat$id)

displacement <- rep(NA, length(id))
for (i in seq_along(id))
{
  match_id <- which(hurdat$id==id[i])
  range.long <- diff(range(hurdat$longitude[match_id]))
  range.lat <- diff(range(hurdat$latitude[match_id]))
  displacement[i] <- sqrt(range.long^2 + range.lat^2) # rough estimate
}

id.by.displacement <- output$id[order(displacement, decreasing = T)]
storm_track(id.by.displacement[1:5]) 

## -----------------------------------------------------------------------------
id <- unique(hurdat$id)
idx <- match(id, hurdat$id)
datetime <- hurdat$datetime[idx]

idx <- 1:nrow(output)
landfall.2 <- sapply(output$id, made_landfall)
occurrences <- table(format(datetime[idx[landfall.2]], "%Y"))
model.info <- data.frame(occurrences)
colnames(model.info) <- c('year', 'occurrences')

accum_cyclone_energy <- sapply(output$id, function(x) tryCatch({cyclone_energy(x)}, error = function(e) {return(NA)}))
model.info$intensity <- aggregate(accum_cyclone_energy,
                              by = list(format(datetime[idx], "%Y")),
                              FUN = mean)$x
model.info$max_speed <- aggregate(output$max_speed,
                              by = list(format(datetime[idx], "%Y")),
                              FUN = mean)$x

model.info$year <- as.numeric(model.info$year) + 1850
landfall.mod <- lm(occurrences ~ year + intensity + I(intensity^2), data = model.info, na.action = na.exclude)
summary(landfall.mod)

## -----------------------------------------------------------------------------
id <- unique(hurdat$id)
idx <- match(id, hurdat$id)
durations <- sapply(id, function(x) {difftime(range(hurdat$datetime[hurdat$id == x])[2], range(hurdat$datetime[hurdat$id == x])[1], units = "hours")})
model.info.2 <- cbind(output, year = as.numeric(format(hurdat$datetime[idx], "%Y")), duration = durations)
model.info.2 <- na.omit(model.info.2)
intensity.mod <- lm(accum_cyclone_energy ~ year + duration + min_pressure, data = model.info.2)
summary(intensity.mod)

## -----------------------------------------------------------------------------
GTA <- read.csv("Global_Temp_Anomalies.csv")
plot(GTA, type = "l", main = "Global Temperature Anomaly vs. Year")
abline(h = 0)
warming.info.3 <- model.info[model.info$year >= 1880, ]

GTA.subset <- subset(GTA, Year >= 1880)

warming.info.3 <- cbind(warming.info.3, temp_anomaly = GTA.subset$Temp_Anomaly)
warming.info.3

lm.warming <- lm(occurrences ~ temp_anomaly, data = warming.info.3)
summary(lm.warming)

tg1 <- 1880:1970
tg2 <- 1980:2022
store <- c()

set.seed(4520)
for(i in 1:1000) {
  tp1 <- sample(tg1, 1)
  tp2 <- sample(tg2, 1)
  pred.1 <- predict(lm.warming, newdata = data.frame(year = tp1, temp_anomaly = GTA.subset[GTA.subset$Year == tp1, 'Temp_Anomaly']))
  pred.2 <- predict(lm.warming, newdata = data.frame(year = tp2, temp_anomaly = GTA.subset[GTA.subset$Year == tp2, 'Temp_Anomaly']))
  store[i] <- (pred.2 - pred.1)/pred.1

}

quantile(store, probs = c(0.05, 0.95))


